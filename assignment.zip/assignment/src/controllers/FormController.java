/*
 * Alex vergara
 * Professor Jackson
 * Date: 2/14/2021
 * JSF Application
 * THIS IS MY OWN WORK
 * 
 */
package controllers;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import beans.User;
//import business.MyTimerService;
import business.OrdersBusinessInterface;
import business.OrdersBusinessService;

@ManagedBean
public class FormController {

	@Inject
	OrdersBusinessInterface service;
	
	//@EJB
	//MyTimerService timer;
	
	
	public String onSubmit() {
		//gets the user values from the input form
		FacesContext context = FacesContext.getCurrentInstance();
		User user1 = context.getApplication().evaluateExpressionGet(context, "#{user}", User.class);
		
		// prints message to console to tell which business service is currently selected in the beans.xml file
		// as an alternative
		service.test();
		
		//set timer
		//timer.setTimer(2000);
		
		
		// show the user object data in the console log
		System.out.println("You clicked the submit button");
		System.out.println("The first name is " + user1.getFirstName());
		System.out.println("The last name is " + user1.getLastName());
		
		//put the user object into the post request
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user1);
		
		// show the next page
		return "Response.xhtml";
	}
	
	
	public OrdersBusinessInterface getService() {
		return service;
		
	}
	
}
