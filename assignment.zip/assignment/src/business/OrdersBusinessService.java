package business;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.Order;

//Alex Vergara
//Design and Implement EJB's
//Date: 3/6/2021
//Professor Jackson
//this is my own work
@Stateless
@Local(OrdersBusinessInterface.class)
@Alternative
public class OrdersBusinessService implements OrdersBusinessInterface{
	
	//create list of orders
	List<Order> orders = new ArrayList<Order>();

	//constructor
	public OrdersBusinessService() {
		
		orders.add(new Order("00000000", "This is product 1", (float)1121.00,1));
		orders.add(new Order("00000001", "This is product 2", (float)312.00,14));
		orders.add(new Order("00000002", "This is product 3", (float)161212.00,1100));
		orders.add(new Order("00000003", "This is product 4", (float)2011.00,1838));
		orders.add(new Order("00000004", "This is product 5", (float)1000.00,1382));
		orders.add(new Order("00000005", "This is product 6", (float)15000.00,1382));
		orders.add(new Order("00000006", "This is product 7", (float)140000.00,1222));
		orders.add(new Order("00000007", "This is product 8", (float)181711.00,12323));
		orders.add(new Order("00000008", "This is product 9", (float)16762.00,1121));
		orders.add(new Order("00000009", "This is product 10", (float)10002.00,1121));
		
	}
	
	// confirm class is being utilized
	@Override
	public void test() {
		System.out.println("");
		System.out.println(" ------------- This Application is running OrdersBusinessService #1  ----------------");
		
	}
	
	
	// get orders
	@Override
	public List<Order> getOrders() {
		return orders;
	}

	// set orders
	@Override
	public void setOrders(List<Order> orders) {
		this.orders = orders;
		
	}

}
