package business;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.Order;


// Alex Vergara
// Design and Implement EJB's
// Date: 3/6/2021
// Professor Jackson
// this is my own work
@Stateless
@Local(OrdersBusinessInterface.class)
@Alternative
public class AnotherOrdersBusinessService implements OrdersBusinessInterface{
	
	// Create List of orders
	List<Order> orders = new ArrayList<Order>();

	// constructor
	public AnotherOrdersBusinessService() {
		// add orders to list
		orders.add(new Order("0000000a", "Product A from alternative BS", (float)1121.00,1));
		orders.add(new Order("0000000b", "Product B from alternative BS", (float)312.00,14));
		orders.add(new Order("0000000c", "Product C from alternative BS", (float)1612.00,1100));
		orders.add(new Order("0000000d", "Product D from alternative BS", (float)211.00,1838));
		orders.add(new Order("0000000e", "Product E from alternative BS", (float)100.00,1382));
		orders.add(new Order("0000000f", "Product F from alternative BS", (float)1000.00,1382));
		orders.add(new Order("0000000g", "Product G from alternative BS", (float)10000.00,1222));
		orders.add(new Order("0000000h", "Product H from alternative BS", (float)11711.00,12323));
		orders.add(new Order("0000000i", "Product I from alternative BS", (float)1762.00,1121));
		orders.add(new Order("0000000j", "Product J from alternative BS", (float)1002.00,1121));
	}

	// confirm class is being utilized
	@Override
	public void test() {
		System.out.println(" ------------- This Application is running AnotherOrdersBusinessService ----------------");
		
	}
	

	// get orders
	@Override
	public List<Order> getOrders() {
		return orders;
	}
	
	// set orders
	@Override
	public void setOrders(List<Order> orders) {
		this.orders = orders;
		
	}

}
