package business;

import java.util.List;

import javax.ejb.Local;

import beans.Order;

//Alex Vergara
//Design and Implement EJB's
//Date: 3/6/2021
//Professor Jackson
//this is my own work
@Local
public interface OrdersBusinessInterface {

	// methods
	public void test();
	public List<Order> getOrders();
	public void setOrders(List<Order> orders);
	
}
